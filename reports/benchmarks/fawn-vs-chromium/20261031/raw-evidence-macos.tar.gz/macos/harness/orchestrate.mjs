#!/usr/bin/env node
// Balanced fresh-launch schedule. For each page and repetition the arm order is
// the next permutation of all arms, so every arm holds every position equally
// often when reps is a multiple of arms! (3 arms: 6 permutations; 12 reps -> 2 each).
// Every launch holds the host GPU lock:
//   darwin: flock(1) on the given lock file around the launch process
//   win32:  atomic mkdir of the lock directory; removed after the launch
// Usage: node orchestrate.mjs --config config.json --out DIR [--reps N] [--pages a,b]
import { spawnSync, execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmdirSync, writeFileSync, appendFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const opt = (k, d) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d; };
const cfg = JSON.parse(readFileSync(opt("--config"), "utf8"));
const out = opt("--out");
const reps = Number(opt("--reps", cfg.reps ?? 12));
const pages = (opt("--pages") ?? cfg.pages.join(",")).split(",");
const arms = cfg.arms;
mkdirSync(join(out, "launches"), { recursive: true });
const log = (s) => { const line = `${new Date().toISOString()} ${s}`; console.log(line); appendFileSync(join(out, "orchestrate.log"), line + "\n"); };

function permutations(a) {
  if (a.length <= 1) return [a];
  return a.flatMap((x, i) => permutations([...a.slice(0, i), ...a.slice(i + 1)]).map((p) => [x, ...p]));
}
const perms = permutations(arms.map((a) => a.id));
const schedule = [];
for (let rep = 0; rep < reps; rep += 1) {
  for (const [pi, page] of pages.entries()) {
    const order = perms[(rep + pi) % perms.length];
    order.forEach((arm, pos) => schedule.push({ rep, page, arm, pos }));
  }
}
writeFileSync(join(out, "schedule.json"), JSON.stringify({ reps, pages, arms: arms.map((a) => a.id), perms, schedule }, null, 1));

const sleepSync = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
function windowsBuildActive() {
  const outp = execFileSync("tasklist", ["/FO", "CSV", "/NH"], { encoding: "utf8" });
  return outp.split("\n").map((l) => l.split(",")[0]?.replace(/"/g, "").toLowerCase()).filter((n) => /^(clang-cl|ninja|siso|lld-link)\.exe$/.test(n));
}

for (const [i, s] of schedule.entries()) {
  const arm = arms.find((a) => a.id === s.arm);
  const name = `${s.page}.${s.arm}.r${String(s.rep).padStart(2, "0")}`;
  const resPath = join(out, "launches", `${name}.json`);
  if (existsSync(resPath)) continue;
  const spec = { ...cfg.launch, arm: s.arm, rep: s.rep, page: s.page, position: s.pos, browserPath: arm.browserPath,
    args: arm.args, expectDoe: arm.expectDoe, keepPng: s.rep === 0 };
  const specPath = join(out, "launches", `${name}.spec.json`);
  writeFileSync(specPath, JSON.stringify(spec));
  const cmd = [join(HERE, "launch.mjs"), "--spec", specPath, "--out", resPath];
  let r;
  if (process.platform === "darwin") {
    r = spawnSync("flock", [cfg.lock, process.execPath, ...cmd], { stdio: "inherit", timeout: 300000 });
  } else {
    for (;;) {
      const busy = windowsBuildActive();
      if (busy.length) { log(`build active (${[...new Set(busy)].join(",")}); waiting`); sleepSync(60000); continue; }
      try { mkdirSync(cfg.lock); break; } catch (e) { if (e.code !== "EEXIST") throw e; log("lock held; waiting"); sleepSync(15000); }
    }
    try { r = spawnSync(process.execPath, cmd, { stdio: "inherit", timeout: 300000 }); }
    finally { rmdirSync(cfg.lock); }
  }
  log(`[${i + 1}/${schedule.length}] ${name} exit=${r.status}${r.error ? " " + r.error : ""}`);
}
log("schedule complete");
