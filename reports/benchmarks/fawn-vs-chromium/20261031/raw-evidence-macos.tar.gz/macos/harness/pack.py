#!/usr/bin/env python3
"""Copy a run's receipts into a report directory with private paths and user
names replaced, then tar them. Usage: python3 -I pack.py RUN_DIR OUT_TGZ LABEL"""
import io
import re
import sys
import tarfile
from pathlib import Path

RULES = [
    (re.compile(re.escape(str(Path.home() / "fawn-bench-stock"))), "<bench>"),
    (re.compile(re.escape(str(Path.home() / "deco" / "doe"))), "<repo>"),
    (re.compile(re.escape(str(Path.home()))), "<home>"),
    (re.compile(r"C:(\\\\|\\|/)Users(\\\\|\\|/)" + "htimskcolc"[::-1] + r"(\\\\|\\|/)fawn-bench", re.I), "<bench>"),
    (re.compile(r"C:(\\\\|\\|/)Users(\\\\|\\|/)" + "htimskcolc"[::-1] + r"", re.I), "<home>"),
    (re.compile(r"<tmp>"' ]*"), "<tmp>"),
    (re.compile("htimskcolc"[::-1] + r"|\b" + re.escape(Path.home().name) + r"\b", re.I), "<user>"),
]
FORBIDDEN = re.compile("|".join(w[::-1] for w in ("selim", "retipuj", "tenliat", "ten.st", "htimskcolc", "/sresU/")), re.I)


def clean(text):
    for rx, rep in RULES:
        text = rx.sub(rep, text)
    return text


def main():
    run, out, label = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
    extra = [Path(p) for p in sys.argv[4:]]
    with tarfile.open(out, "w:gz") as tar:
        files = sorted(p for p in run.rglob("*") if p.is_file()) + extra
        for p in files:
            arc = f"{label}/{p.relative_to(run)}" if p.is_relative_to(run) else f"{label}/harness/{p.name}"
            data = p.read_bytes()
            if p.suffix != ".png":
                text = clean(data.decode("utf-8"))
                bad = FORBIDDEN.search(text)
                if bad:
                    raise SystemExit(f"unsanitized token {bad.group(0)!r} in {p}")
                data = text.encode()
            info = tarfile.TarInfo(arc)
            info.size = len(data)
            info.mtime = 0
            info.mode = 0o644
            tar.addfile(info, io.BytesIO(data))
    print(out)


if __name__ == "__main__":
    main()
