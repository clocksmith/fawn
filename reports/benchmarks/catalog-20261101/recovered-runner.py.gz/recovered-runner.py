#!/usr/bin/env python3
"""Unified catalog benchmark runner for Doe C vs Dawn (with Dawn A/A control).

Runs all 127 workloads from bench/workloads/metadata/backend-workload-catalog.json:
- Freezes prospective contract (contract.json + contract.sha256) before timing.
- Acquires host GPU timing lock per workload window:
  - POSIX (macOS Metal, Linux Intel Vulkan): flock /tmp/doe-gpu-timing.lock
  - Linux Intel Vulkan (suby): pauses ChatGPT desktop app during timed windows and resumes in finally
  - Windows (miles D3D12 & AMD Vulkan): atomic mkdir C:\\Users\\clocksmith\\doe-gpu-lock after verifying no compiler runs
- Collects cold and warm runs, A/A Dawn control, p50/p95 per phase (setup, encode, submit_wait,
  operation, complete), CPU time (cpu_ms), and peak memory (max_rss_mib), with 2,000-resample
  bootstrap 95% CIs and adaptive pair top-up to resolve 5%.
"""
import argparse
import ctypes
import glob
import hashlib
import json
import math
import os
from pathlib import Path
import random
import shutil
import signal
import subprocess
import sys
import tempfile
import time

if os.name != "nt":
  import fcntl
else:
  import ctypes.wintypes as wt


BACKEND_PROFILES = {
    "apple-metal": {
        "api": "metal",
        "vendor": "apple",
        "family": "m3",
        "driver": "1.0.0",
        "quirks": "examples/quirks/apple_m3_noop_list.json",
        "doe_emitter": "doe-emit-msl-c",
        "tint_format": "msl",
    },
    "intel-vulkan": {
        "api": "vulkan",
        "vendor": "intel",
        "family": "gen12",
        "driver": "31.0.101",
        "quirks": "examples/quirks/intel_gen12_temp_buffer_list.json",
        "doe_emitter": "doe-emit-msl-c",
        "tint_format": "msl",
    },
    "windows-amd-vulkan": {
        "api": "vulkan",
        "vendor": "amd",
        "family": "gfx11",
        "driver": "24.0.0",
        "quirks": "examples/quirks/amd_radv_noop_list.json",
        "doe_emitter": "doe-emit-msl-c",
        "tint_format": "msl",
    },
    "windows-d3d12": {
        "api": "d3d12",
        "vendor": "amd",
        "family": "d3d12",
        "driver": "1.0.0",
        "quirks": "examples/quirks/windows_d3d12_noop_list.json",
        "doe_emitter": "doe-emit-msl-c",
        "tint_format": "msl",
    },
}

PERMUTATIONS = [
    ("doe", "dawn", "dawn-aa"),
    ("dawn", "dawn-aa", "doe"),
    ("dawn-aa", "doe", "dawn"),
    ("doe", "dawn-aa", "dawn"),
    ("dawn", "doe", "dawn-aa"),
    ("dawn-aa", "dawn", "doe"),
]

METRICS = [
    "cold.setup_ms",
    "cold.encode_ms",
    "cold.submit_wait_ms",
    "cold.operation_ms",
    "cold.complete_ms",
    "warm.setup_ms",
    "warm.encode_ms",
    "warm.submit_wait_ms",
    "warm.operation_ms",
    "warm.complete_ms",
    "cpu_ms",
    "max_rss_mib",
]


def sha256_file(path):
  if not path or not os.path.exists(path):
    return None
  h = hashlib.sha256()
  with open(path, "rb") as f:
    while True:
      b = f.read(65536)
      if not b:
        break
      h.update(b)
  return h.hexdigest()


def find_chatgpt_pids():
  if os.name == "nt":
    return []
  pids = []
  for cmdline_path in glob.glob("/proc/[0-9]*/cmdline"):
    try:
      pid = int(cmdline_path.split("/")[2])
      raw = open(cmdline_path, "rb").read()
      if b"/usr/lib/chatgpt/ChatGPT" in raw:
        pids.append(pid)
    except Exception:
      pass
  return pids


def windows_compilers_running():
  if os.name != "nt":
    return False
  try:
    r = subprocess.run(
        ["tasklist", "/FO", "CSV", "/NH"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    compilers = {
        "clang-cl.exe",
        "cl.exe",
        "ninja.exe",
        "siso.exe",
        "lld-link.exe",
        "link.exe",
    }
    for line in r.stdout.splitlines():
      if line.startswith('"'):
        img = line.split('"', 2)[1].lower()
        if img in compilers:
          return True
  except Exception:
    pass
  return False


class WindowLock:

  def __init__(self, lock_path, backend):
    self.lock_path = lock_path
    self.backend = backend
    self.lock_f = None
    self.chatgpt_pids = []

  def __enter__(self):
    if os.name == "nt":
      while True:
        while windows_compilers_running():
          time.sleep(1.0)
        try:
          os.mkdir(self.lock_path)
          break
        except FileExistsError:
          time.sleep(0.5)
    else:
      self.lock_f = open(self.lock_path, "a+")
      fcntl.flock(self.lock_f.fileno(), fcntl.LOCK_EX)
      if self.backend == "intel-vulkan":
        self.chatgpt_pids = find_chatgpt_pids()
        for pid in self.chatgpt_pids:
          try:
            os.kill(pid, signal.SIGSTOP)
          except Exception:
            pass
    return self

  def __exit__(self, exc_type, exc_val, exc_tb):
    if os.name == "nt":
      try:
        os.rmdir(self.lock_path)
      except Exception:
        pass
    else:
      for pid in self.chatgpt_pids:
        try:
          os.kill(pid, signal.SIGCONT)
        except Exception:
          pass
      if self.lock_f is not None:
        try:
          fcntl.flock(self.lock_f.fileno(), fcntl.LOCK_UN)
        except Exception:
          pass
        self.lock_f.close()


if os.name == "nt":
  _k32 = ctypes.WinDLL("kernel32", use_last_error=True)
  _psapi = ctypes.WinDLL("psapi", use_last_error=True)

  class _PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("cb", wt.DWORD),
        ("PageFaultCount", wt.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]

  def _win_ft_to_100ns(ft):
    return (ft.dwHighDateTime << 32) | ft.dwLowDateTime


def run_process_with_rusage(cmd, cwd, env, timeout=90):
  t0 = time.perf_counter_ns()
  if os.name == "nt":
    proc = subprocess.Popen(
        cmd,
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    try:
      stdout_b, stderr_b = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
      subprocess.run(
          ["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True
      )
      proc.communicate()
      raise
    wall_ms = (time.perf_counter_ns() - t0) / 1e6
    cpu_ms = 0.0
    max_rss_mib = 0.0
    try:
      h = wt.HANDLE(int(proc._handle))
      c_ft, e_ft, k_ft, u_ft = (
          wt.FILETIME(),
          wt.FILETIME(),
          wt.FILETIME(),
          wt.FILETIME(),
      )
      if _k32.GetProcessTimes(
          h,
          ctypes.byref(c_ft),
          ctypes.byref(e_ft),
          ctypes.byref(k_ft),
          ctypes.byref(u_ft),
      ):
        cpu_ms = (_win_ft_to_100ns(k_ft) + _win_ft_to_100ns(u_ft)) / 1e4
      pmc = _PROCESS_MEMORY_COUNTERS()
      pmc.cb = ctypes.sizeof(_PROCESS_MEMORY_COUNTERS)
      if _k32.K32GetProcessMemoryInfo(
          h, ctypes.byref(pmc), pmc.cb
      ) or _psapi.GetProcessMemoryInfo(h, ctypes.byref(pmc), pmc.cb):
        max_rss_mib = pmc.PeakWorkingSetSize / (1024.0 * 1024.0)
    except Exception:
      pass
    return proc.returncode, stdout_b, stderr_b, wall_ms, cpu_ms, max_rss_mib
  else:
    with tempfile.TemporaryFile() as out_f, tempfile.TemporaryFile() as err_f:
      proc = subprocess.Popen(
          cmd,
          cwd=cwd,
          env=env,
          stdout=out_f,
          stderr=err_f,
      )
      deadline = time.monotonic() + timeout
      rusage = None
      status = 0
      while True:
        pid, st, ru = os.wait4(proc.pid, os.WNOHANG)
        if pid == proc.pid:
          status = st
          rusage = ru
          break
        if time.monotonic() > deadline:
          try:
            os.kill(proc.pid, signal.SIGKILL)
          except Exception:
            pass
          os.wait4(proc.pid, 0)
          raise subprocess.TimeoutExpired(cmd, timeout)
        time.sleep(0.0005)
      wall_ms = (time.perf_counter_ns() - t0) / 1e6
      proc.returncode = os.waitstatus_to_exitcode(status)
      out_f.seek(0)
      err_f.seek(0)
      stdout_b = out_f.read()
      stderr_b = err_f.read()
      cpu_ms = (rusage.ru_utime + rusage.ru_stime) * 1000.0 if rusage else 0.0
      if rusage:
        if sys.platform == "darwin":
          max_rss_mib = rusage.ru_maxrss / (1024.0 * 1024.0)
        else:
          max_rss_mib = rusage.ru_maxrss / 1024.0
      else:
        max_rss_mib = 0.0
      return proc.returncode, stdout_b, stderr_b, wall_ms, cpu_ms, max_rss_mib


def resolve_workload_spec(w):
  wid = w["id"]
  sh = dict(w.get("shared", {}))
  lanes = w.get("lanes", {})
  merged = dict(sh)
  for lval in lanes.values():
    for k, v in lval.items():
      if k not in merged or merged[k] in (None, "", []):
        merged[k] = v
  rtype = merged.get("runnerType", "zig-runtime")
  if rtype == "compilation":
    return {
        "id": wid,
        "kind": "compilation",
        "domain": merged.get("domain", "compilation"),
        "shaderPath": merged["shaderPath"],
        "catalogTarget": merged.get("compilationTarget", "msl"),
    }
  ir_path = merged.get("irPath")
  if ir_path:
    return {
        "id": wid,
        "kind": "plan",
        "domain": merged.get("domain", "inference"),
        "planPath": f"bench/plans/generated/{wid}.plan.json",
        "commandsPath": f"bench/plans/generated/compat/{wid}_commands.json",
        "extraArgs": merged.get("extraArgs", []),
        "catalogRepeat": 1,
    }
  cpath = merged.get("commandsPath")
  extra_args = list(merged.get("extraArgs") or [])
  repeat = (
      merged.get("comparisonCommandRepeat")
      or merged.get("commandRepeat")
      or merged.get("baselineCommandRepeat")
      or 1
  )
  return {
      "id": wid,
      "kind": "commands",
      "domain": merged.get("domain", "general"),
      "commandsPath": cpath,
      "extraArgs": extra_args,
      "catalogRepeat": int(repeat),
  }


def build_runtime_cmd(binary, spec, profile, trace_jsonl, trace_meta, repeat=1):
  extra = list(spec.get("extraArgs") or [])
  if spec["kind"] == "plan":
    cmd = [
        binary,
        "--execute",
        "--plan",
        spec["planPath"],
        "--workload",
        spec["id"],
        "--vendor",
        profile["vendor"],
        "--family",
        profile["family"],
        "--api",
        profile["api"],
        "--driver",
        profile["driver"],
        "--trace-jsonl",
        trace_jsonl,
        "--trace-meta",
        trace_meta,
        "--queue-wait-mode",
        "process-events",
    ]
    if "--queue-sync-mode" not in extra:
      cmd.extend(["--queue-sync-mode", "per-command"])
    cmd.extend(extra)
    return cmd

  cmd = [
      binary,
      "--execute",
      "--commands",
      spec["commandsPath"],
      "--vendor",
      profile["vendor"],
      "--family",
      profile["family"],
      "--api",
      profile["api"],
      "--driver",
      profile["driver"],
      "--quirks",
      profile["quirks"],
      "--trace",
      "--trace-jsonl",
      trace_jsonl,
      "--trace-meta",
      trace_meta,
      "--queue-wait-mode",
      "process-events",
  ]
  if "--queue-sync-mode" not in extra:
    cmd.extend(["--queue-sync-mode", "per-command"])
  if "--kernel-root" not in extra:
    cmd.extend(["--kernel-root", "bench/kernels"])
  cmd.extend(extra)
  cmd.extend(["--command-repeat", str(repeat)])
  return cmd


def execute_arm_sample(
    arm_bin, spec, profile, root, tmpdir, env, repeat_for_commands=2
):
  if spec["kind"] == "compilation":
    sp = os.path.join(root, spec["shaderPath"])
    if not arm_bin or not os.path.exists(arm_bin):
      return {
          "ok": False,
          "reason": "posix_compiler_cli_not_built_on_windows",
          "message": f"missing compiler binary {arm_bin}",
      }
    is_tint = os.path.basename(arm_bin).lower().startswith("tint")
    cmd = (
        [arm_bin, "--format", profile["tint_format"], sp]
        if is_tint
        else [arm_bin, "--shader-path", sp]
    )
    try:
      rc1, out1, err1, wall1, cpu1, rss1 = run_process_with_rusage(
          cmd, root, env, timeout=30
      )
      rc2, out2, err2, wall2, cpu2, rss2 = run_process_with_rusage(
          cmd, root, env, timeout=30
      )
    except subprocess.TimeoutExpired:
      return {
          "ok": False,
          "reason": "timeout",
          "message": "compilation timed out",
      }
    ok = (rc1 == 0) and (rc2 == 0) and (len(out1) > 0)
    if not ok:
      return {
          "ok": False,
          "reason": "compile_error",
          "message": err1.decode("utf-8", "replace").strip()[:200],
      }
    return {
        "ok": True,
        "metrics": {
            "cold.setup_ms": wall1,
            "cold.encode_ms": 0.0,
            "cold.submit_wait_ms": 0.0,
            "cold.operation_ms": wall1,
            "cold.complete_ms": wall1,
            "warm.setup_ms": wall2,
            "warm.encode_ms": 0.0,
            "warm.submit_wait_ms": 0.0,
            "warm.operation_ms": wall2,
            "warm.complete_ms": wall2,
            "cpu_ms": (cpu1 + cpu2) / 2.0,
            "max_rss_mib": max(rss1, rss2),
        },
    }

  if spec["kind"] == "plan":
    t_jsonl = os.path.join(tmpdir, "trace_plan.jsonl")
    t_meta = os.path.join(tmpdir, "trace_plan.meta.json")
    for p in (t_jsonl, t_meta):
      if os.path.exists(p):
        os.unlink(p)
    cmd = build_runtime_cmd(arm_bin, spec, profile, t_jsonl, t_meta, repeat=1)
    try:
      rc, out_b, err_b, wall_ms, cpu_ms, rss_mib = run_process_with_rusage(
          cmd, root, env, timeout=90
      )
    except subprocess.TimeoutExpired:
      return {
          "ok": False,
          "reason": "timeout",
          "message": "plan timed out after 90s",
      }
    meta = {}
    if os.path.exists(t_meta):
      try:
        meta = json.load(open(t_meta, encoding="utf-8"))
      except Exception:
        pass
    if (
        rc != 0
        or not meta
        or meta.get("executionErrorCount", 0) > 0
        or meta.get("gpuCompletionUnknown", False)
    ):
      return {
          "ok": False,
          "reason": meta.get("executionStatusCode") or f"exit_{rc}",
          "message": (
              meta.get("executionStatusMessage")
              or err_b.decode("utf-8", "replace").strip()[:200]
          ),
      }
    init_ms = meta.get("hostExecutorInitTotalNs", 0) / 1e6
    setup_ms = meta.get("executionSetupTotalNs", 0) / 1e6
    encode_ms = meta.get("executionEncodeTotalNs", 0) / 1e6
    submit_ms = meta.get("executionSubmitWaitTotalNs", 0) / 1e6
    op_ms = meta.get("executionTotalNs", 0) / 1e6

    rows = []
    if os.path.exists(t_jsonl):
      with open(t_jsonl, encoding="utf-8") as f:
        rows = [json.loads(line) for line in f if line.strip()]
    # Separate first-touch kernel compile steps (cold) from subsequent warm dispatches of already-compiled kernels
    seen_kernels = set()
    cold_setup_ns = 0
    warm_setup_ns = 0
    for r in rows:
      k = r.get("kernel")
      sn = r.get("executionSetupNs", 0)
      if k and k not in seen_kernels:
        seen_kernels.add(k)
        cold_setup_ns += sn
      else:
        warm_setup_ns += sn
    w_setup = warm_setup_ns / 1e6
    w_op = max(0.0, op_ms - (cold_setup_ns / 1e6))
    return {
        "ok": True,
        "metrics": {
            "cold.setup_ms": setup_ms,
            "cold.encode_ms": encode_ms,
            "cold.submit_wait_ms": submit_ms,
            "cold.operation_ms": op_ms,
            "cold.complete_ms": init_ms + op_ms,
            "warm.setup_ms": w_setup,
            "warm.encode_ms": encode_ms,
            "warm.submit_wait_ms": submit_ms,
            "warm.operation_ms": w_op if w_op > 0 else op_ms,
            "warm.complete_ms": init_ms + (w_op if w_op > 0 else op_ms),
            "cpu_ms": cpu_ms,
            "max_rss_mib": rss_mib,
        },
    }

  # kind == "commands"
  R = max(1, repeat_for_commands)
  t_jsonl = os.path.join(tmpdir, "trace_cmd.jsonl")
  t_meta = os.path.join(tmpdir, "trace_cmd.meta.json")
  for p in (t_jsonl, t_meta):
    if os.path.exists(p):
      os.unlink(p)
  cmd = build_runtime_cmd(arm_bin, spec, profile, t_jsonl, t_meta, repeat=R)
  try:
    rc, out_b, err_b, wall_ms, cpu_ms, rss_mib = run_process_with_rusage(
        cmd, root, env, timeout=90
    )
  except subprocess.TimeoutExpired:
    return {
        "ok": False,
        "reason": "timeout",
        "message": "command workload timed out after 90s",
    }
  meta = {}
  if os.path.exists(t_meta):
    try:
      meta = json.load(open(t_meta, encoding="utf-8"))
    except Exception:
      pass
  if (
      rc != 0
      or not meta
      or meta.get("executionErrorCount", 0) > 0
      or meta.get("gpuCompletionUnknown", False)
      or meta.get("executionRowCount", 0) == 0
  ):
    return {
        "ok": False,
        "reason": meta.get("executionStatusCode") or f"exit_{rc}",
        "message": (
            meta.get("executionStatusMessage")
            or err_b.decode("utf-8", "replace").strip()[:200]
        ),
    }
  rows = []
  if os.path.exists(t_jsonl):
    with open(t_jsonl, encoding="utf-8") as f:
      rows = [json.loads(line) for line in f if line.strip()]
  total_rows = len(rows)
  init_ms = meta.get("hostExecutorInitTotalNs", 0) / 1e6
  prewarm_ms = meta.get("hostKernelPrewarmTotalNs", 0) / 1e6

  if R >= 2 and total_rows >= R:
    K = max(1, total_rows // R)
    pass0 = rows[:K]
    warm_rows = rows[K:]
    warm_passes = max(1, R - 1)
  else:
    pass0 = rows
    warm_rows = rows
    warm_passes = 1

  p0_setup_ms = sum(r.get("executionSetupNs", 0) for r in pass0) / 1e6
  p0_encode_ms = sum(r.get("executionEncodeNs", 0) for r in pass0) / 1e6
  p0_submit_ms = sum(r.get("executionSubmitWaitNs", 0) for r in pass0) / 1e6
  p0_dur_ms = sum(r.get("executionDurationNs", 0) for r in pass0) / 1e6

  w_setup_ms = sum(r.get("executionSetupNs", 0) for r in warm_rows) / (
      warm_passes * 1e6
  )
  w_encode_ms = sum(r.get("executionEncodeNs", 0) for r in warm_rows) / (
      warm_passes * 1e6
  )
  w_submit_ms = sum(r.get("executionSubmitWaitNs", 0) for r in warm_rows) / (
      warm_passes * 1e6
  )
  w_dur_ms = sum(r.get("executionDurationNs", 0) for r in warm_rows) / (
      warm_passes * 1e6
  )

  return {
      "ok": True,
      "metrics": {
          "cold.setup_ms": prewarm_ms + p0_setup_ms,
          "cold.encode_ms": p0_encode_ms,
          "cold.submit_wait_ms": p0_submit_ms,
          "cold.operation_ms": prewarm_ms + p0_dur_ms,
          "cold.complete_ms": init_ms + prewarm_ms + p0_dur_ms,
          "warm.setup_ms": w_setup_ms,
          "warm.encode_ms": w_encode_ms,
          "warm.submit_wait_ms": w_submit_ms,
          "warm.operation_ms": w_dur_ms,
          "warm.complete_ms": init_ms + w_dur_ms,
          "cpu_ms": cpu_ms / R,
          "max_rss_mib": rss_mib,
      },
  }


def percentile(sorted_vals, q):
  if not sorted_vals:
    return 0.0
  if len(sorted_vals) == 1:
    return float(sorted_vals[0])
  pos = (len(sorted_vals) - 1) * q
  lo = int(math.floor(pos))
  hi = int(math.ceil(pos))
  if lo == hi:
    return float(sorted_vals[lo])
  return float(
      sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (pos - lo)
  )


def bootstrap_ratio_ci(num_vals, den_vals, rng, resamples=2000):
  n = len(num_vals)
  if n == 0:
    return 1.0, 1.0, [1.0, 1.0]
  eps = 1e-6
  ratios = [max(num_vals[i], eps) / max(den_vals[i], eps) for i in range(n)]
  ratios_sorted = sorted(ratios)
  p50 = percentile(ratios_sorted, 0.50)
  p95 = percentile(ratios_sorted, 0.95)
  if n == 1:
    return p50, p95, [p50, p50]
  boot_medians = []
  for _ in range(resamples):
    sample = sorted(ratios[rng.randrange(n)] for _ in range(n))
    boot_medians.append(sample[n // 2])
  boot_medians.sort()
  ci_lo = boot_medians[int(0.025 * resamples)]
  ci_hi = boot_medians[int(0.975 * resamples)]
  return p50, p95, [ci_lo, ci_hi]


def summarize_workload(wid, spec, pairs_data, seed=20261101):
  rng = random.Random(seed)
  arms_summary = {}
  for arm in ("doe", "dawn", "dawn-aa"):
    arms_summary[arm] = {}
    for m in METRICS:
      vals = sorted(p[arm][m] for p in pairs_data)
      arms_summary[arm][m] = {
          "p50": percentile(vals, 0.50),
          "p95": percentile(vals, 0.95),
      }
  comparisons = {}
  for label, num_arm, den_arm in (
      ("doe/dawn", "doe", "dawn"),
      ("dawn-aa/dawn", "dawn-aa", "dawn"),
  ):
    comparisons[label] = {}
    for m in METRICS:
      num_vals = [p[num_arm][m] for p in pairs_data]
      den_vals = [p[den_arm][m] for p in pairs_data]
      p50, p95, ci95 = bootstrap_ratio_ci(
          num_vals, den_vals, rng, resamples=2000
      )
      comparisons[label][m] = {
          "p50": p50,
          "p95": p95,
          "ci95": ci95,
      }
  return {
      "id": wid,
      "kind": spec["kind"],
      "domain": spec["domain"],
      "supported": True,
      "pairs": len(pairs_data),
      "arms": arms_summary,
      "comparisons": comparisons,
  }


def main():
  ap = argparse.ArgumentParser()
  ap.add_argument(
      "--backend", required=True, choices=list(BACKEND_PROFILES.keys())
  )
  ap.add_argument("--root", required=True)
  ap.add_argument("--doe-bin", required=True)
  ap.add_argument("--dawn-bin", required=True)
  ap.add_argument("--dawn-aa-bin", required=True)
  ap.add_argument("--doe-compiler-dir", default="")
  ap.add_argument("--tint-bin", default="")
  ap.add_argument("--lock-path", default="/tmp/doe-gpu-timing.lock")
  ap.add_argument("--pairs", type=int, default=7)
  ap.add_argument("--max-pairs", type=int, default=11)
  ap.add_argument("--only-workloads", default="")
  ap.add_argument("--out-dir", required=True)
  args = ap.parse_args()

  profile = BACKEND_PROFILES[args.backend]
  out_dir = Path(args.out_dir)
  out_dir.mkdir(parents=True, exist_ok=True)

  cat_path = os.path.join(
      args.root, "bench/workloads/metadata/backend-workload-catalog.json"
  )
  cat = json.load(open(cat_path, encoding="utf-8"))

  doe_emitter_bin = (
      os.path.join(args.doe_compiler_dir, profile["doe_emitter"])
      if args.doe_compiler_dir
      else ""
  )
  tint_aa_bin = ""
  if args.tint_bin and os.path.exists(args.tint_bin):
    tint_aa_bin = str(
        out_dir / ("tint-aa.exe" if os.name == "nt" else "tint-aa")
    )
    if not os.path.exists(tint_aa_bin):
      shutil.copy2(args.tint_bin, tint_aa_bin)

  git_head = subprocess.run(
      ["git", "rev-parse", "HEAD"],
      cwd=args.root,
      capture_output=True,
      text=True,
  ).stdout.strip()

  contract = {
      "schemaVersion": 1,
      "backend": args.backend,
      "gitCommit": git_head,
      "catalogSha256": sha256_file(cat_path),
      "binaries": {
          "doeRuntimeSha256": sha256_file(args.doe_bin),
          "dawnRuntimeSha256": sha256_file(args.dawn_bin),
          "dawnAaRuntimeSha256": sha256_file(args.dawn_aa_bin),
          "doeEmitterSha256": sha256_file(doe_emitter_bin),
          "tintSha256": sha256_file(args.tint_bin),
      },
      "sampling": {
          "initialPairs": args.pairs,
          "maxPairs": args.max_pairs,
          "commandRepeat": 2,
          "bootstrapSeed": 20261101,
          "bootstrapResamples": 2000,
          "targetRelativeHalfWidth": 0.05,
          "permutations": [list(p) for p in PERMUTATIONS],
      },
      "metrics": METRICS,
      "frozenAtUtc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
  }
  contract_path = out_dir / "contract.json"
  contract_path.write_text(
      json.dumps(contract, indent=2, sort_keys=True) + "\n", encoding="utf-8"
  )
  contract_sha = sha256_file(str(contract_path))
  (out_dir / "contract.sha256").write_text(
      contract_sha + "  contract.json\n", encoding="utf-8"
  )
  print(f"[FROZEN CONTRACT] {args.backend} sha256={contract_sha}", flush=True)

  env = os.environ.copy()
  if args.backend == "intel-vulkan":
    env["DISPLAY"] = ":0"
    xauths = sorted(glob.glob("/run/user/*/.mutter-Xwaylandauth.*"))
    if xauths:
      env["XAUTHORITY"] = xauths[0]
  if os.name == "nt" and "DOE_BENCH_ASSET_CACHE_DIR" not in env:
    env["DOE_BENCH_ASSET_CACHE_DIR"] = str(
        Path.home() / ".cache/doe/bench_synthetic_assets"
    )

  only_set = (
      set(x.strip() for x in args.only_workloads.split(",") if x.strip())
      if args.only_workloads
      else None
  )

  results = []
  unsupported = []
  out_file = out_dir / f"catalog_{args.backend}.json"

  with tempfile.TemporaryDirectory() as tmpdir:
    for idx, w in enumerate(cat["workloads"]):
      spec = resolve_workload_spec(w)
      wid = spec["id"]
      if only_set and wid not in only_set:
        continue

      if spec["kind"] == "compilation":
        arm_bins = {
            "doe": doe_emitter_bin,
            "dawn": args.tint_bin,
            "dawn-aa": tint_aa_bin,
        }
      else:
        arm_bins = {
            "doe": args.doe_bin,
            "dawn": args.dawn_bin,
            "dawn-aa": args.dawn_aa_bin,
        }

      # Hold WindowLock for this workload's window
      pairs_data = []
      u_entry = None
      with WindowLock(args.lock_path, args.backend):
        # Pair 0 is also our support check
        p0_doe = execute_arm_sample(
            arm_bins["doe"],
            spec,
            profile,
            args.root,
            tmpdir,
            env,
            repeat_for_commands=2,
        )
        p0_dawn = (
            execute_arm_sample(
                arm_bins["dawn"],
                spec,
                profile,
                args.root,
                tmpdir,
                env,
                repeat_for_commands=2,
            )
            if p0_doe["ok"]
            else {"ok": False, "reason": "skipped_after_doe_fail", "message": ""}
        )
        if not (p0_doe["ok"] and p0_dawn["ok"]):
          u_entry = {
              "id": wid,
              "kind": spec["kind"],
              "domain": spec["domain"],
              "supported": False,
              "doeStatus": (
                  "ok" if p0_doe["ok"] else p0_doe.get("reason", "failed")
              ),
              "doeMessage": p0_doe.get("message", ""),
              "dawnStatus": (
                  "ok" if p0_dawn["ok"] else p0_dawn.get("reason", "failed")
              ),
              "dawnMessage": p0_dawn.get("message", ""),
          }
        else:
          p0_aa = execute_arm_sample(
              arm_bins["dawn-aa"],
              spec,
              profile,
              args.root,
              tmpdir,
              env,
              repeat_for_commands=2,
          )
          if p0_aa["ok"]:
            pairs_data.append({
                "doe": p0_doe["metrics"],
                "dawn": p0_dawn["metrics"],
                "dawn-aa": p0_aa["metrics"],
            })
          max_warm_ms = max(
              p0_doe["metrics"]["warm.operation_ms"],
              p0_dawn["metrics"]["warm.operation_ms"],
          )
          cmd_repeat = 1 if max_warm_ms >= 150.0 else 2
          target_pairs = (
              3
              if max_warm_ms >= 1200.0
              else (5 if max_warm_ms >= 250.0 else args.pairs)
          )

          p_idx = len(pairs_data)
          while p_idx < target_pairs:
            perm = PERMUTATIONS[p_idx % len(PERMUTATIONS)]
            pair_rec = {}
            ok_pair = True
            for arm in perm:
              res = execute_arm_sample(
                  arm_bins[arm],
                  spec,
                  profile,
                  args.root,
                  tmpdir,
                  env,
                  repeat_for_commands=cmd_repeat,
              )
              if not res["ok"]:
                ok_pair = False
                break
              pair_rec[arm] = res["metrics"]
            if not ok_pair:
              break
            pairs_data.append(pair_rec)
            p_idx += 1

            if (
                p_idx == target_pairs
                and target_pairs < args.max_pairs
                and max_warm_ms < 50.0
            ):
              tmp_sum = summarize_workload(wid, spec, pairs_data)
              op_cmp = tmp_sum["comparisons"]["doe/dawn"]["warm.operation_ms"]
              med = max(op_cmp["p50"], 1e-6)
              rel_hw = (op_cmp["ci95"][1] - op_cmp["ci95"][0]) / (2.0 * med)
              if rel_hw > 0.05:
                target_pairs = min(args.max_pairs, target_pairs + 4)

      if u_entry is not None:
        unsupported.append(u_entry)
        results.append(u_entry)
        print(
            f"[{idx+1:3d}/127] {wid:62s} UNSUPPORTED"
            f" (doe={u_entry['doeStatus']}, dawn={u_entry['dawnStatus']})",
            flush=True,
        )
      else:
        summary = summarize_workload(wid, spec, pairs_data)
        results.append(summary)
        op = summary["comparisons"]["doe/dawn"]["warm.operation_ms"]
        aa = summary["comparisons"]["dawn-aa/dawn"]["warm.operation_ms"]
        print(
            f"[{idx+1:3d}/127] {wid:62s} OK pairs={len(pairs_data):2d} "
            f"warm.op doe/dawn={op['p50']:.3f}x"
            f" [{op['ci95'][0]:.3f},{op['ci95'][1]:.3f}] "
            f"aa={aa['p50']:.3f}x "
            f"(doe={summary['arms']['doe']['warm.operation_ms']['p50']:.2f}ms,"
            f" dawn={summary['arms']['dawn']['warm.operation_ms']['p50']:.2f}ms)",
            flush=True,
        )

      # Incremental checkpoint save
      out_payload = {
          "backend": args.backend,
          "contract": contract,
          "contractSha256": contract_sha,
          "supportedCount": sum(1 for r in results if r.get("supported")),
          "unsupportedCount": len(unsupported),
          "unsupportedWorkloads": unsupported,
          "workloads": results,
      }
      out_file.write_text(
          json.dumps(out_payload, indent=2) + "\n", encoding="utf-8"
      )

  print(
      f"[COMPLETE] {args.backend}: {out_payload['supportedCount']} supported,"
      f" {out_payload['unsupportedCount']} unsupported -> {out_file}",
      flush=True,
  )


if __name__ == "__main__":
  main()
