# SPDX-License-Identifier: MIT
"""Private prospective PDH leaf: SDK layout, raw snapshots, official calculation.
No thresholds, process tracking, GPU work or counter rate formula lives here.
"""
from pathlib import Path
import ctypes as C, ctypes.wintypes as W, json
root=Path(__file__).parent
class Raw(C.Structure):_fields_=[('CStatus',W.DWORD),('TimeStamp',W.FILETIME),('FirstValue',C.c_longlong),('SecondValue',C.c_longlong),('MultiCount',W.DWORD)]
class RawItem(C.Structure):_fields_=[('name',W.LPWSTR),('raw',Raw)]
class Value(C.Union):_fields_=[('longValue',W.LONG),('doubleValue',C.c_double),('largeValue',C.c_longlong),('AnsiStringValue',W.LPCSTR),('WideStringValue',W.LPCWSTR)]
class Fmt(C.Structure):_anonymous_=('value',);_fields_=[('CStatus',W.DWORD),('value',Value)]
class FmtItem(C.Structure):_fields_=[('name',W.LPWSTR),('fmt',Fmt)]
layout={'raw_size':C.sizeof(Raw),'raw_align':C.alignment(Raw),'raw_status':Raw.CStatus.offset,'raw_time':Raw.TimeStamp.offset,'raw_first':Raw.FirstValue.offset,'raw_second':Raw.SecondValue.offset,'raw_multi':Raw.MultiCount.offset,'raw_item_size':C.sizeof(RawItem),'raw_item_value':RawItem.raw.offset,'fmt_size':C.sizeof(Fmt),'fmt_value':Fmt.value.offset,'fmt_item_size':C.sizeof(FmtItem),'fmt_item_value':FmtItem.fmt.offset}
assert layout==json.loads((root/'sdk-layout.json').read_text()),layout
pdh=C.WinDLL('pdh',use_last_error=True)
pdh.PdhOpenQueryW.argtypes=[W.LPCWSTR,C.c_size_t,C.POINTER(W.HANDLE)];pdh.PdhOpenQueryW.restype=W.LONG
pdh.PdhAddEnglishCounterW.argtypes=[W.HANDLE,W.LPCWSTR,C.c_size_t,C.POINTER(W.HANDLE)];pdh.PdhAddEnglishCounterW.restype=W.LONG
pdh.PdhCollectQueryData.argtypes=[W.HANDLE];pdh.PdhCollectQueryData.restype=W.LONG
pdh.PdhGetRawCounterArrayW.argtypes=[W.HANDLE,C.POINTER(W.DWORD),C.POINTER(W.DWORD),W.LPVOID];pdh.PdhGetRawCounterArrayW.restype=W.LONG
pdh.PdhGetFormattedCounterArrayW.argtypes=[W.HANDLE,W.DWORD,C.POINTER(W.DWORD),C.POINTER(W.DWORD),W.LPVOID];pdh.PdhGetFormattedCounterArrayW.restype=W.LONG
pdh.PdhCalculateCounterFromRawValue.argtypes=[W.HANDLE,W.DWORD,C.POINTER(Raw),C.POINTER(Raw),C.POINTER(Fmt)];pdh.PdhCalculateCounterFromRawValue.restype=W.LONG
pdh.PdhCloseQuery.argtypes=[W.HANDLE];pdh.PdhCloseQuery.restype=W.LONG

code=lambda value:value & 0xffffffff

def raw_array(handle):
    attempts=[]
    for _ in range(3):
        size=W.DWORD();count=W.DWORD()
        status=code(pdh.PdhGetRawCounterArrayW(handle,C.byref(size),C.byref(count),None))
        row={'sizeStatus':f'{status:08x}','bytes':size.value,'sizeCount':count.value};attempts.append(row)
        if status!=0x800007d2:return None,{'attempts':attempts,'status':f'{status:08x}'}
        buffer=(C.c_byte*size.value)()
        status=code(pdh.PdhGetRawCounterArrayW(handle,C.byref(size),C.byref(count),buffer));row.update(fillStatus=f'{status:08x}',fillCount=count.value)
        if status in (0x800007d2,0xc0000bbd):continue  # resize only by fresh size query
        if status!=0:return None,{'attempts':attempts,'status':f'{status:08x}'}
        items=C.cast(buffer,C.POINTER(RawItem));result={}
        for i in range(count.value):
            item=items[i];result[item.name]=Raw.from_buffer_copy(C.string_at(C.byref(item.raw),C.sizeof(Raw)))
        return result,{'attempts':attempts,'status':'00000000','count':len(result)}
    return None,{'attempts':attempts,'status':'buffer_resize_exhausted'}

def calculate(handle,new,old):
    value=Fmt();status=code(pdh.PdhCalculateCounterFromRawValue(handle,0x200,C.byref(new),C.byref(old),C.byref(value)))
    return {'callStatus':f'{status:08x}','valueStatus':value.CStatus,'value':value.doubleValue if status==0 and value.CStatus in (0,1) else None}

def raw_json(raw):
    return {'status':raw.CStatus,'timestamp':(raw.TimeStamp.dwHighDateTime<<32)|raw.TimeStamp.dwLowDateTime,'first':raw.FirstValue,'second':raw.SecondValue,'multi':raw.MultiCount}

def interval(current,previous,identities,prior_identities,calculator):
    """Return one explicit eligibility record per current or disappeared key.
    Calculator is the official PDH call in production; injection tests call admission.
    """
    records=[]
    for name in sorted(set(current)|set(previous)):
        identity=identities.get(name) or prior_identities.get(name) or {'category':'foreign','identity':'unresolved','image':None,'birth':None}
        row={'counter':name,**identity,'value':None};new=current.get(name);old=previous.get(name)
        if new is not None:row['raw']=raw_json(new)
        if old is not None:row['previousRaw']=raw_json(old)
        if new is None:row['missing']='disappeared_instance'
        elif old is None:row['missing']='first_or_new_instance'
        elif new.CStatus not in (0,1):row['missing']='invalid_current_raw'
        elif old.CStatus not in (0,1):row['missing']='invalid_previous_raw'
        elif identity.get('birth')!=prior_identities.get(name,{}).get('birth'):row['missing']='new_process_lifetime'
        elif identity['category']=='foreign' and identity.get('identity')=='unresolved':row['missing']='unattributed_foreign'
        else:
            value=calculator(new,old);row['calculation']=value
            if value['value'] is None:row['missing']='invalid_calculation'
            else:row['value']=value['value']
        records.append(row)
    return records
