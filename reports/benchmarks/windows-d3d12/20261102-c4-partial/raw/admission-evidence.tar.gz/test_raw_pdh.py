# SPDX-License-Identifier: MIT
import unittest
from unittest.mock import patch
import raw_pdh
import ctypes as C
from raw_pdh import Raw,interval,layout
class Eligibility(unittest.TestCase):
 def setUp(self):
  self.raw=Raw();self.raw.CStatus=0;self.raw.FirstValue=10;self.raw.SecondValue=20
  self.ident={'k':{'category':'foreign','identity':'live-fullpath','image':'known.exe','birth':1}}
  self.calls=0
 def calc(self,new,old):self.calls+=1;return {'callStatus':'00000000','valueStatus':0,'value':1.25}
 def test_stable_calls_official_boundary(self):
  r=interval({'k':self.raw},{'k':self.raw},self.ident,self.ident,self.calc)[0];self.assertEqual(r['value'],1.25);self.assertEqual(self.calls,1)
 def test_first_new_disappeared_not_zero(self):
  for current,previous,reason in [({'k':self.raw},{},'first_or_new_instance'),({}, {'k':self.raw},'disappeared_instance')]:
   r=interval(current,previous,self.ident,self.ident,self.calc)[0];self.assertEqual(r['missing'],reason);self.assertIsNone(r['value'])
  self.assertEqual(self.calls,0)
 def test_invalid_status_never_calculated(self):
  bad=Raw();bad.CStatus=0xc0000bba
  for current,previous in [({'k':bad},{'k':self.raw}),({'k':self.raw},{'k':bad})]:self.assertIsNone(interval(current,previous,self.ident,self.ident,self.calc)[0]['value'])
  self.assertEqual(self.calls,0)
 def test_lifetime_change_and_unattributed_foreign_missing(self):
  for facts in [dict(self.ident['k'],birth=2),dict(self.ident['k'],identity='unresolved')]:
   r=interval({'k':self.raw},{'k':self.raw},{'k':facts},self.ident,self.calc)[0];self.assertIsNone(r['value'])
  self.assertEqual(self.calls,0)
 def test_failed_calculation_not_zero(self):
  r=interval({'k':self.raw},{'k':self.raw},self.ident,self.ident,lambda n,o:{'callStatus':'c0000bba','valueStatus':0xc0000bba,'value':None})[0];self.assertEqual(r['missing'],'invalid_calculation');self.assertIsNone(r['value'])
 def test_array_call_failure_is_missing(self):
  class API:
   @staticmethod
   def PdhGetRawCounterArrayW(*args):return 0xc0000bba
  with patch.object(raw_pdh,'pdh',API()):
   values,meta=raw_pdh.raw_array(None)
  self.assertIsNone(values);self.assertEqual(meta['status'],'c0000bba')
 def test_array_fill_failure_does_not_read_zero_buffer(self):
  class API:
   @staticmethod
   def PdhGetRawCounterArrayW(handle,size,count,buffer):
    if buffer is None:
     C.cast(size,C.POINTER(raw_pdh.W.DWORD)).contents.value=128
     C.cast(count,C.POINTER(raw_pdh.W.DWORD)).contents.value=1
     return 0x800007d2
    return 0xc0000bba
  with patch.object(raw_pdh,'pdh',API()):
   values,meta=raw_pdh.raw_array(None)
  self.assertIsNone(values);self.assertEqual(meta['attempts'][0]['fillStatus'],'c0000bba')
if __name__=='__main__':unittest.main()
