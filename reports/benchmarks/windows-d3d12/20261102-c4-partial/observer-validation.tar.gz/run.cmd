@echo off
setlocal
call C:\Users\clocksmith\AppData\Local\deco\toolchains\vs2022-buildtools\Common7\Tools\VsDevCmd.bat -arch=x64 >nul
if not "%errorlevel%"=="0" exit /b %errorlevel%
C:\Users\clocksmith\AppData\Local\deco\toolchains\vs2022-buildtools\VC\Tools\Llvm\x64\bin\clang-cl.exe /nologo /MD /O2 /WX /clang:-std=c11 /clang:-Wall /clang:-Wextra /clang:-Wpedantic C:\Users\clocksmith\AppData\Local\Temp\fawn-win-c4fba1230d-20261102T223258Z\pdh-raw-probe-20261102T225618Z\layout.c /FoC:\Users\clocksmith\AppData\Local\Temp\fawn-win-c4fba1230d-20261102T223258Z\pdh-raw-probe-20261102T225618Z\layout.obj /FeC:\Users\clocksmith\AppData\Local\Temp\fawn-win-c4fba1230d-20261102T223258Z\pdh-raw-probe-20261102T225618Z\layout.exe
if not "%errorlevel%"=="0" exit /b %errorlevel%
C:\Users\clocksmith\AppData\Local\Temp\fawn-win-c4fba1230d-20261102T223258Z\pdh-raw-probe-20261102T225618Z\layout.exe >C:\Users\clocksmith\AppData\Local\Temp\fawn-win-c4fba1230d-20261102T223258Z\pdh-raw-probe-20261102T225618Z\sdk-layout.json
if not "%errorlevel%"=="0" exit /b %errorlevel%
C:\Users\clocksmith\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe C:\Users\clocksmith\AppData\Local\Temp\fawn-win-c4fba1230d-20261102T223258Z\pdh-raw-probe-20261102T225618Z\probe.py
if not "%errorlevel%"=="0" exit /b %errorlevel%
exit /b 0
