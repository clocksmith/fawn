/* SPDX-License-Identifier: MIT */
#include <windows.h>
#include <pdh.h>
#include <stddef.h>
#include <stdio.h>
int main(void) {
    printf("{\"raw_size\":%zu,\"raw_align\":%zu,\"raw_status\":%zu,\"raw_time\":%zu,\"raw_first\":%zu,\"raw_second\":%zu,\"raw_multi\":%zu,\"raw_item_size\":%zu,\"raw_item_value\":%zu,\"fmt_size\":%zu,\"fmt_value\":%zu,\"fmt_item_size\":%zu,\"fmt_item_value\":%zu}\n", sizeof(PDH_RAW_COUNTER), _Alignof(PDH_RAW_COUNTER), offsetof(PDH_RAW_COUNTER,CStatus), offsetof(PDH_RAW_COUNTER,TimeStamp), offsetof(PDH_RAW_COUNTER,FirstValue), offsetof(PDH_RAW_COUNTER,SecondValue), offsetof(PDH_RAW_COUNTER,MultiCount), sizeof(PDH_RAW_COUNTER_ITEM_W), offsetof(PDH_RAW_COUNTER_ITEM_W,RawValue), sizeof(PDH_FMT_COUNTERVALUE), offsetof(PDH_FMT_COUNTERVALUE,doubleValue), sizeof(PDH_FMT_COUNTERVALUE_ITEM_W), offsetof(PDH_FMT_COUNTERVALUE_ITEM_W,FmtValue));
    return 0;
}
