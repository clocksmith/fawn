from pathlib import Path
import ctypes as C,ctypes.wintypes as W,json,time,os,sys,struct
root=Path(__file__).parent
class Raw(C.Structure):_fields_=[('CStatus',W.DWORD),('TimeStamp',W.FILETIME),('FirstValue',C.c_longlong),('SecondValue',C.c_longlong),('MultiCount',W.DWORD)]
class RawItem(C.Structure):_fields_=[('name',W.LPWSTR),('raw',Raw)]
class Value(C.Union):_fields_=[('longValue',W.LONG),('doubleValue',C.c_double),('largeValue',C.c_longlong),('AnsiStringValue',W.LPCSTR),('WideStringValue',W.LPCWSTR)]
class Fmt(C.Structure):_anonymous_=('value',);_fields_=[('CStatus',W.DWORD),('value',Value)]
class FmtItem(C.Structure):_fields_=[('name',W.LPWSTR),('fmt',Fmt)]
layout={'raw_size':C.sizeof(Raw),'raw_align':C.alignment(Raw),'raw_status':Raw.CStatus.offset,'raw_time':Raw.TimeStamp.offset,'raw_first':Raw.FirstValue.offset,'raw_second':Raw.SecondValue.offset,'raw_multi':Raw.MultiCount.offset,'raw_item_size':C.sizeof(RawItem),'raw_item_value':RawItem.raw.offset,'fmt_size':C.sizeof(Fmt),'fmt_value':Fmt.value.offset,'fmt_item_size':C.sizeof(FmtItem),'fmt_item_value':FmtItem.fmt.offset}
assert layout==json.loads((root/'sdk-layout.json').read_text()),layout
pdh=C.WinDLL('pdh',use_last_error=True)
pdh.PdhOpenQueryW.argtypes=[W.LPCWSTR,C.c_size_t,C.POINTER(W.HANDLE)];pdh.PdhOpenQueryW.restype=W.LONG
pdh.PdhAddEnglishCounterW.argtypes=[W.HANDLE,W.LPCWSTR,C.c_size_t,C.POINTER(W.HANDLE)];pdh.PdhAddEnglishCounterW.restype=W.LONG
pdh.PdhCollectQueryData.argtypes=[W.HANDLE];pdh.PdhCollectQueryData.restype=W.LONG
pdh.PdhGetRawCounterArrayW.argtypes=[W.HANDLE,C.POINTER(W.DWORD),C.POINTER(W.DWORD),W.LPVOID];pdh.PdhGetRawCounterArrayW.restype=W.LONG
pdh.PdhGetFormattedCounterArrayW.argtypes=[W.HANDLE,W.DWORD,C.POINTER(W.DWORD),C.POINTER(W.DWORD),W.LPVOID];pdh.PdhGetFormattedCounterArrayW.restype=W.LONG
pdh.PdhCalculateCounterFromRawValue.argtypes=[W.HANDLE,W.DWORD,C.POINTER(Raw),C.POINTER(Raw),C.POINTER(Fmt)];pdh.PdhCalculateCounterFromRawValue.restype=W.LONG
pdh.PdhCloseQuery.argtypes=[W.HANDLE];pdh.PdhCloseQuery.restype=W.LONG
code=lambda v:v&0xffffffff
query=W.HANDLE();assert pdh.PdhOpenQueryW(None,0,C.byref(query))==0
counters={}
for name,path in [('gpu',r'\GPU Engine(*)\Utilization Percentage'),('cpu',r'\Processor(*)\% Processor Time')]:
 handle=W.HANDLE();assert pdh.PdhAddEnglishCounterW(query,path,0,C.byref(handle))==0;counters[name]=handle

def array(handle,raw):
 size=W.DWORD();count=W.DWORD();fn=pdh.PdhGetRawCounterArrayW if raw else pdh.PdhGetFormattedCounterArrayW
 args=[handle] if raw else [handle,0x200]
 status=code(fn(*args,C.byref(size),C.byref(count),None));meta={'size_status':f'{status:08x}','size_bytes':size.value,'size_count':count.value}
 if status!=0x800007d2:return None,meta
 buffer=(C.c_byte*size.value)();status=code(fn(*args,C.byref(size),C.byref(count),buffer));meta.update(fill_status=f'{status:08x}',fill_count=count.value)
 if status!=0:return None,meta
 items=C.cast(buffer,C.POINTER(RawItem if raw else FmtItem));result={}
 for i in range(count.value):
  item=items[i]
  if raw:result[item.name]=Raw.from_buffer_copy(C.string_at(C.byref(item.raw),C.sizeof(Raw)))
  else:result[item.name]={'status':item.fmt.CStatus,'value':item.fmt.doubleValue if item.fmt.CStatus in (0,1) else None}
 return result,meta

lock=Path.home()/'doe-gpu-lock';os.mkdir(lock)
previous={};samples=[]
try:
 for index in range(11):
  if index:time.sleep(1)
  status=code(pdh.PdhCollectQueryData(query));sample={'index':index,'t':time.time(),'collect_status':f'{status:08x}','counters':{}}
  for name,handle in counters.items():
   current,raw_meta=array(handle,True);formatted,fmt_meta=array(handle,False);prev=previous.get(name,{});rows=[]
   if current is not None:
    for key,new in current.items():
     old=prev.get(key);row={'instance':key,'raw_status':new.CStatus,'new':old is None,'FirstValue':new.FirstValue,'SecondValue':new.SecondValue}
     if old is not None and new.CStatus in (0,1) and old.CStatus in (0,1):
      value=Fmt();calc=code(pdh.PdhCalculateCounterFromRawValue(handle,0x200,C.byref(new),C.byref(old),C.byref(value)));row.update(calc_status=f'{calc:08x}',value_status=value.CStatus,calculated=value.doubleValue if calc==0 and value.CStatus in (0,1) else None)
     else:row['missing']='first_or_new_instance' if old is None else 'invalid_raw_status'
     direct=formatted.get(key) if formatted is not None else None
     if direct is not None:row['formatted']=direct
     if row.get('calculated') is not None and direct is not None and direct['value'] is not None:row.update(abs_difference=abs(row['calculated']-direct['value']),exact_equal=struct.pack('d',row['calculated'])==struct.pack('d',direct['value']))
     rows.append(row)
    previous[name]=current
   sample['counters'][name]={'raw_array':raw_meta,'formatted_array':fmt_meta,'rows':rows,'disappeared_instances':sorted(set(prev)-set(current or {})),'whole_raw_missing':current is None}
  samples.append(sample);(root/'samples.json').write_text(json.dumps(samples,indent=2)+'\n')
finally:
 assert pdh.PdhCloseQuery(query)==0;lock.rmdir()
compared=[(kind,row) for sample in samples for kind,counter in sample['counters'].items() for row in counter['rows'] if 'exact_equal'in row];summary={'sdk_layout':layout,'samples':len(samples),'compared':len(compared),'nonzero_compared':sum(row['calculated']!=0 for _,row in compared),'exact_matches':sum(row['exact_equal'] for _,row in compared),'max_abs_difference':max((row['abs_difference'] for _,row in compared),default=None),'by_counter':{kind:sum(k==kind for k,_ in compared) for kind in counters},'query_lock_released':not lock.exists()};(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));assert compared and all(row['exact_equal'] for _,row in compared)
