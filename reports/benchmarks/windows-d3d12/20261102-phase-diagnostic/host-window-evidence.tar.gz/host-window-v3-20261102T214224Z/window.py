"""Gated Windows timing window: GPU lock, cohort run, foreign-load sampler, validity.

window.py <out dir rel home> <src rel home> -- <cohort run args...>
Foreign CPU = (GetSystemTimes busy - window tree CPU) / (wall x logical CPUs), where
the window tree is this process, the cohort process and every harness child
(childCpuMs). Foreign GPU = mean over 1 s samples of the max, across engines, of
summed PDH "GPU Engine(*)\\Utilization Percentage" for processes whose image is not
a harness-*.exe and not System (PID 4). System GPU time is WDDM video-memory
paging/zeroing done for every process; it is recorded separately (systemGpuPct). A
15 s pre-window sample under the lock, before any harness starts, must show all
GPU time including System <= 2% and foreign CPU <= 5%, so foreign paging cannot hide
there. Valid iff pre-window and window foreign GPU <= 2%, foreign CPU <= 5%, no
failed process, and the Dawn A/A check passes (checked by the gate script).
"""
from pathlib import Path
import ctypes, ctypes.wintypes as wt, json, os, subprocess, sys, threading, time
h = Path.home(); out = h / sys.argv[1]; src = h / sys.argv[2]; cohort = sys.argv[sys.argv.index('--') + 1:]
out.mkdir(parents=True, exist_ok=False)
k32 = ctypes.WinDLL('kernel32', use_last_error=True); pdh = ctypes.WinDLL('pdh')
k32.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]; k32.OpenProcess.restype = wt.HANDLE
k32.GetCurrentProcess.restype = wt.HANDLE
k32.QueryFullProcessImageNameW.argtypes = [wt.HANDLE, wt.DWORD, wt.LPWSTR, ctypes.POINTER(wt.DWORD)]
k32.CloseHandle.argtypes = [wt.HANDLE]
def checked(status, name):
    if status != 0: raise RuntimeError(f'{name}: 0x{status & 0xffffffff:08x}')
prepared = json.loads((Path(__file__).parent / 'original-frozen-contract.json').read_text())
allowed_harnesses = {str(Path(p)).lower() for p in prepared['providers'].values()}
allowed_harnesses.add(str(Path('C:\\Users\\<user>\\AppData\\Local\\Temp\\fawn-win-cohort-50cf8feb84-20261102T202125Z\\products\\native\\write_order.exe')).lower())
image_paths = {}

def ft(f): return (f.dwHighDateTime << 32) | f.dwLowDateTime
def systimes():
    i, k, u = wt.FILETIME(), wt.FILETIME(), wt.FILETIME()
    if not k32.GetSystemTimes(ctypes.byref(i), ctypes.byref(k), ctypes.byref(u)): raise OSError(ctypes.get_last_error())
    return ft(i), ft(k), ft(u)
def proctimes(handle):
    t = [wt.FILETIME() for _ in range(4)]
    if not k32.GetProcessTimes(wt.HANDLE(handle), *map(ctypes.byref, t)): raise OSError(ctypes.get_last_error())
    return (ft(t[2]) + ft(t[3])) / 1e4
names = {}; identities = {}; tracker_errors = []
def image(pid):
    hp = k32.OpenProcess(0x1000, False, pid); buf = ctypes.create_unicode_buffer(32768); n = wt.DWORD(32768)
    try:
        if hp and k32.QueryFullProcessImageNameW(hp, 0, buf, ctypes.byref(n)):
            image_paths[pid] = buf.value.lower(); identities[pid] = 'live-fullpath'
        elif pid in image_paths: identities[pid] = 'cached-observed-fullpath'
        else: image_paths[pid] = f'?{pid}'; identities[pid] = 'unresolved'
    finally:
        if hp: k32.CloseHandle(hp)
    names[pid] = Path(image_paths[pid]).name
    return names[pid]
class PROCESSENTRY32(ctypes.Structure):
    _fields_ = [('dwSize', wt.DWORD), ('cntUsage', wt.DWORD), ('th32ProcessID', wt.DWORD),
                ('th32DefaultHeapID', ctypes.c_size_t), ('th32ModuleID', wt.DWORD), ('cntThreads', wt.DWORD),
                ('th32ParentProcessID', wt.DWORD), ('pcPriClassBase', wt.LONG), ('dwFlags', wt.DWORD), ('szExeFile', wt.WCHAR * 260)]
k32.CreateToolhelp32Snapshot.argtypes = [wt.DWORD, wt.DWORD]; k32.CreateToolhelp32Snapshot.restype = wt.HANDLE
k32.Process32FirstW.argtypes = [wt.HANDLE, ctypes.POINTER(PROCESSENTRY32)]
k32.Process32NextW.argtypes = [wt.HANDLE, ctypes.POINTER(PROCESSENTRY32)]
allowed_names = {Path(p).name for p in allowed_harnesses}
def track_processes():
    try:
        while not stop.is_set():
            snapshot = k32.CreateToolhelp32Snapshot(2, 0)
            if snapshot == ctypes.c_void_p(-1).value: raise OSError(ctypes.get_last_error())
            try:
                row = PROCESSENTRY32(); row.dwSize = ctypes.sizeof(row)
                ok = k32.Process32FirstW(snapshot, ctypes.byref(row))
                if not ok: raise OSError(ctypes.get_last_error())
                while ok:
                    if row.szExeFile.lower() in allowed_names: image(row.th32ProcessID)
                    ok = k32.Process32NextW(snapshot, ctypes.byref(row))
                if ctypes.get_last_error() != 18: raise OSError(ctypes.get_last_error())
            finally: k32.CloseHandle(snapshot)
            stop.wait(0.05)
    except BaseException as exc: tracker_errors.append(repr(exc))
class ITEM(ctypes.Structure):
    _fields_ = [('name', wt.LPWSTR), ('status', wt.DWORD), ('pad', wt.DWORD), ('value', ctypes.c_double)]
query = wt.HANDLE(); counter = wt.HANDLE()
checked(pdh.PdhOpenQueryW(None, None, ctypes.byref(query)), 'PdhOpenQueryW')
checked(pdh.PdhAddEnglishCounterW(query, '\\GPU Engine(*)\\Utilization Percentage', None, ctypes.byref(counter)), 'PdhAddEnglishCounterW')
checked(pdh.PdhCollectQueryData(query), 'PdhCollectQueryData')
samples = []; sampling_errors = []; stop = threading.Event()
def collect_samples():
    while not stop.wait(1.0):
        checked(pdh.PdhCollectQueryData(query), 'PdhCollectQueryData')
        size = wt.DWORD(0); count = wt.DWORD(0)
        first = pdh.PdhGetFormattedCounterArrayW(counter, 0x200, ctypes.byref(size), ctypes.byref(count), None)
        if first & 0xffffffff != 0x800007d2: raise RuntimeError(f'PDH array size status: {first & 0xffffffff:08x}')
        buf = (ctypes.c_byte * size.value)()
        if count.value == 0: raise RuntimeError('PDH GPU counter has no instances')
        checked(pdh.PdhGetFormattedCounterArrayW(counter, 0x200, ctypes.byref(size), ctypes.byref(count), buf), 'PdhGetFormattedCounterArrayW')
        items = ctypes.cast(buf, ctypes.POINTER(ITEM)); engines = {}; harness = {}; system = {}; top = {}; missing = []; status_counts = {}
        for j in range(count.value):
            name, status = items[j].name, items[j].status
            pid = int(name.split('_')[1]); eng = name.split('_luid_')[1]; img = image(pid)
            category = 'own' if image_paths[pid] in allowed_harnesses else 'system' if pid == 4 else 'foreign'
            status_counts[f'{status:08x}'] = status_counts.get(f'{status:08x}', 0) + 1
            if status not in (0, 1):
                missing.append({'counter':name, 'pid':pid, 'status':f'{status:08x}', 'category':category,
                                'image':image_paths[pid], 'identity':identities[pid]})
                continue  # unavailable value is retained as missing, never used as zero
            v = items[j].value
            if v <= 0: continue
            d = harness if category == 'own' else system if category == 'system' else engines
            d[eng] = d.get(eng, 0.0) + v
            key = img + '|' + name.rsplit('engtype_', 1)[-1]
            top[key] = top.get(key, 0.0) + v
        foreign_missing = sum(x['category'] == 'foreign' for x in missing)
        system_missing = sum(x['category'] == 'system' for x in missing)
        own_missing = sum(x['category'] == 'own' for x in missing)
        samples.append({'t': time.time(), 'instances':count.value, 'statusCounts':status_counts, 'missingInstances':missing,
                        'foreignMissingInstances':foreign_missing, 'systemMissingInstances':system_missing, 'ownMissingInstances':own_missing,
                        'foreignMaxEngine':None if foreign_missing else max(engines.values(), default=0.0),
                        'foreignKnownLowerBound':max(engines.values(), default=0.0),
                        'harnessMaxEngine':None if own_missing else max(harness.values(), default=0.0),
                        'systemMaxEngine':None if system_missing else max(system.values(), default=0.0),
                        'byImageEngine': dict(sorted(top.items(), key=lambda x: -x[1])[:8])})
def sample():
    try: collect_samples()
    except BaseException as exc: sampling_errors.append(repr(exc)); stop.set()
lock = h / 'doe-gpu-lock'; waited = time.time()
while True:
    try: os.mkdir(lock); break
    except FileExistsError: raise SystemExit('Canonical GPU lock busy; no observation/run admitted')
try:
    (out / 'lock.json').write_text(json.dumps({'waitedS': time.time() - waited, 'acquired': time.time()}))
    me = k32.GetCurrentProcess(); tracker = threading.Thread(target=track_processes, daemon=True); tracker.start(); th = threading.Thread(target=sample, daemon=True); th.start()
    p0 = proctimes(me); q0 = systimes(); time.sleep(15); q1 = systimes(); p1 = proctimes(me)
    pre_samples = list(samples)
    pre_complete = all(all(x[k] is not None for k in ['foreignMaxEngine','systemMaxEngine','harnessMaxEngine']) for x in pre_samples)
    pre = {'wallS': 15, 'gpuSamples':len(pre_samples), 'allGpuCoverage':sum(all(x[k] is not None for k in ['foreignMaxEngine','systemMaxEngine','harnessMaxEngine']) for x in pre_samples)/max(1,len(pre_samples)), 'allGpuPct': (sum(x['foreignMaxEngine'] + x['systemMaxEngine'] + x['harnessMaxEngine'] for x in pre_samples) / max(1, len(pre_samples))) if pre_complete else None,
           'foreignCpuPct': 100 * (((q1[1] - q0[1]) + (q1[2] - q0[2]) - (q1[0] - q0[0])) / 1e4 - (p1 - p0)) / (15e3 * os.cpu_count())}
    (out / 'pre-gpu-samples.jsonl').write_text(''.join(json.dumps(s) + '\n' for s in pre_samples))
    if sampling_errors or tracker_errors or len(pre_samples) < 14: raise RuntimeError(f'Pre-window sampler unhealthy: {sampling_errors}, samples={len(pre_samples)}')
    (out / 'pre-window.json').write_text(json.dumps(pre, indent=2) + '\n')
    if not pre_complete or pre['allGpuPct'] > 2.0 or pre['foreignCpuPct'] > 5.0:
        raise SystemExit('Measured pre-window exceeds retained 2% GPU / 5% CPU limits; no workload admitted')
    del samples[:]
    cpu0 = proctimes(me); s0 = systimes(); w0 = time.monotonic()
    if cohort[0] == 'IDLE':  # idle probe: same sampler, no harness
        time.sleep(float(cohort[1])); log = 'idle'; cohort_cpu = 0.0; p = subprocess.CompletedProcess([], 0)
    elif cohort[0] == 'CONTROL':
        p = subprocess.Popen(cohort[1:], cwd=src / 'runtime/c/native', stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        log = p.communicate()[0]; cohort_cpu = proctimes(int(p._handle))
        time.sleep(max(0, 15 - (time.monotonic() - w0)))  # bounded correctness observation, not a performance interval
    else:
        p = subprocess.Popen([sys.executable, str(src / 'bench/cli.py'), 'phase-cohort', 'run', *cohort], cwd=src,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        log = p.communicate()[0]; cohort_cpu = proctimes(int(p._handle))
    stop.set(); th.join(); tracker.join(); wall = time.monotonic() - w0; s1 = systimes(); cpu1 = proctimes(me)
finally:
    os.rmdir(lock)
(out / 'cohort.log').write_text(log)
rows = [] if cohort[0] in ('IDLE', 'CONTROL') else [json.loads(l) for l in Path(cohort[cohort.index('--out') + 1]).read_text().splitlines() if l.strip()]
children = sum(r['childCpuMs'] for r in rows)
busy = ((s1[1] - s0[1]) + (s1[2] - s0[2]) - (s1[0] - s0[0])) / 1e4
ncpu = os.cpu_count(); own = (cpu1 - cpu0) + cohort_cpu + children
gate = {'wallS': wall, 'logicalCpus': ncpu, 'systemBusyMs': busy, 'windowTreeCpuMs': own, 'harnessChildCpuMs': children,
        'foreignCpuPct': 100 * (busy - own) / (wall * 1e3 * ncpu), 'gpuSamples': len(samples),
        'foreignGpuCoverage':sum(s['foreignMaxEngine'] is not None for s in samples)/max(1,len(samples)),
        'foreignGpuPct': sum(s['foreignMaxEngine'] for s in samples) / max(1,len(samples)) if all(s['foreignMaxEngine'] is not None for s in samples) else None,
        'harnessGpuPct': sum(s['harnessMaxEngine'] for s in samples) / max(1,len(samples)) if all(s['harnessMaxEngine'] is not None for s in samples) else None,
        'systemGpuPct': sum(s['systemMaxEngine'] for s in samples) / max(1,len(samples)) if all(s['systemMaxEngine'] is not None for s in samples) else None, 'preWindow': pre,
        'failedProcesses': (int(p.returncode != 0) if cohort[0] == 'CONTROL' else sum(1 for r in rows if r['returnCode'] != 0 or r['result'].get('status') != 'ok')),
        'cohortReturnCode': p.returncode, 'processes': len(rows), 'samplingErrors': sampling_errors, 'identityTrackerErrors':tracker_errors, 'missingInstances':sum(len(s['missingInstances']) for s in samples), 'foreignMissingInstances':sum(s['foreignMissingInstances'] for s in samples)}
gate['gateValid'] = (p.returncode == 0 and not sampling_errors and not tracker_errors and gate['foreignGpuCoverage'] == 1.0 and gate['gpuSamples'] >= max(1, int(wall)-1) and gate['foreignGpuPct'] <= 2.0 and gate['foreignCpuPct'] <= 5.0 and gate['failedProcesses'] == 0
                    and pre['allGpuPct'] <= 2.0 and pre['foreignCpuPct'] <= 5.0)
(out / 'gate.json').write_text(json.dumps(gate, indent=2) + '\n')
(out / 'gpu-samples.jsonl').write_text(''.join(json.dumps(s) + '\n' for s in samples))
print(json.dumps(gate))
