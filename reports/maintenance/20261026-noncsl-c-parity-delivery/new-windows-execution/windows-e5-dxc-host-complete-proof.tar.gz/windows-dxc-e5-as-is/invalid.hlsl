this is invalid HLSL;
