
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<u32>;
@compute @workgroup_size(1) fn main(@builtin(global_invocation_id) id: vec3u) {
  let i = id.x; let v = vec4f(input[i], input[(i+1u)%12u], input[(i+2u)%12u], input[(i+3u)%12u]);
  output[i*3u] = pack4x8unorm(v); output[i*3u+1u] = pack4x8snorm(v);
  output[i*3u+2u] = pack2x16float(v.xy);
}