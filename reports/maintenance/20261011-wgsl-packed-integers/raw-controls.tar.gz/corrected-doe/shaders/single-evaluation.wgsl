requires packed_4x8_integer_dot_product;
@group(0) @binding(0) var<storage, read> input: array<u32>;
@group(0) @binding(1) var<storage, read_write> output: array<u32>;
var<private> calls: u32;
fn word() -> u32 { calls += 1u; return input[calls - 1u]; }
fn negative_values() -> vec4i { calls += 1u; return vec4i(-129, -128, 127, 128); }
fn positive_values() -> vec4u { calls += 1u; return vec4u(0u, 255u, 256u, 0xffffffffu); }
@compute @workgroup_size(1) fn main() {
  output[0] = pack4xI8(negative_values()); output[1] = pack4xI8Clamp(negative_values());
  output[2] = pack4xU8(positive_values()); output[3] = pack4xU8Clamp(positive_values());
  output[4] = u32(unpack4xI8(word()).w); output[5] = unpack4xU8(word()).w;
  output[6] = u32(dot4I8Packed(word(), word())); output[7] = dot4U8Packed(word(), word());
  output[8] = calls;
}