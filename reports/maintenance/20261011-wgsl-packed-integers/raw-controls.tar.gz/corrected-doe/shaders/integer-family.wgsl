requires packed_4x8_integer_dot_product;
@group(0) @binding(0) var<storage, read> input: array<u32>;
@group(0) @binding(1) var<storage, read_write> output: array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) id: vec3u) {
  if (id.x >= 66573u) { return; }
  let p = id.x * 10u;
  let q = id.x * 16u;
  let unsigned = vec4u(input[p], input[p+1u], input[p+2u], input[p+3u]);
  let signed = bitcast<vec4i>(vec4u(input[p+4u], input[p+5u], input[p+6u], input[p+7u]));
  let a = input[p+8u]; let b = input[p+9u];
  let s = unpack4xI8(a); let u = unpack4xU8(a);
  output[q] = u32(s.x); output[q+1u] = u32(s.y);
  output[q+2u] = u32(s.z); output[q+3u] = u32(s.w);
  output[q+4u] = u.x; output[q+5u] = u.y; output[q+6u] = u.z; output[q+7u] = u.w;
  output[q+8u] = pack4xI8(signed); output[q+9u] = pack4xU8(unsigned);
  output[q+10u] = pack4xI8Clamp(signed); output[q+11u] = pack4xU8Clamp(unsigned);
  output[q+12u] = u32(dot4I8Packed(a, b)); output[q+13u] = dot4U8Packed(a, b);
  output[q+14u] = pack4xI8(s); output[q+15u] = pack4xU8(u);
}