
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<u32>;
@compute @workgroup_size(1) fn main(@builtin(global_invocation_id) id: vec3u) {
  let i = id.x; let v = vec2f(input[i], input[(i+1u)%12u]);
  let u = pack2x16unorm(v); let s = pack2x16snorm(v);
  output[i*4u] = u; output[i*4u+1u] = s;
  output[i*4u+2u] = pack2x16unorm(unpack2x16unorm(u));
  output[i*4u+3u] = pack2x16snorm(unpack2x16snorm(s));
}