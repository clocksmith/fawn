requires packed_4x8_integer_dot_product;
const signed_word = pack4xI8(vec4i(-129, -128, 127, 128));
const unsigned_word = pack4xU8(vec4u(0u, 255u, 256u, 0xffffffffu));
const signed_clamp = pack4xI8Clamp(vec4i(-129, -128, 127, 128));
const unsigned_clamp = pack4xU8Clamp(vec4u(0u, 255u, 256u, 0xffffffffu));
const signed_bytes = unpack4xI8(0x80ff017f);
const unsigned_bytes = unpack4xU8(0x80ff017f);
const signed_dot = dot4I8Packed(0x80808080, 0x7f7f7f7f);
const unsigned_dot = dot4U8Packed(0xffffffff, 0xffffffff);
const splat = pack4xI8(vec4i(-1));
const joined = pack4xU8(vec4u(vec2u(1u, 2u), vec2u(3u, 4u)));
const inferred = pack4xU8(vec4(1, 2, 3, 4));
@group(0) @binding(0) var<storage, read> input: array<u32>;
@group(0) @binding(1) var<storage, read_write> output: array<u32>;
@compute @workgroup_size(1) fn main() {
  output[0] = signed_word; output[1] = unsigned_word;
  output[2] = signed_clamp; output[3] = unsigned_clamp;
  output[4] = u32(signed_bytes.x); output[5] = u32(signed_bytes.y);
  output[6] = u32(signed_bytes.z); output[7] = u32(signed_bytes.w);
  output[8] = unsigned_bytes.x; output[9] = unsigned_bytes.y;
  output[10] = unsigned_bytes.z; output[11] = unsigned_bytes.w;
  output[12] = u32(signed_dot); output[13] = unsigned_dot;
  output[14] = splat; output[15] = joined; output[16] = inferred;
  output[17] = pack4xU8(vec4(1, 2, 3, 4));
  output[18] = pack4xI8(vec4(-1, -2, 3, 4)); output[19] = input[0];
}